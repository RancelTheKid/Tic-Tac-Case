class GameBtn extends HTMLElement {
  connectedCallback() {
const link = this.getAttribute("link");
    
const image = this.getAttribute("image");

const alt = this.getAttribute("alt") || "Game";
    
    this.innerHTML = `
    <a href="${link}" class="game-btn">
      <img src="${image}" alt="${alt}" class="game-img">
    </a>
    `;
  }
}

customElements.define("game-btn", GameBtn);

class GameCard extends HTMLElement {
  connectedCallback() {
  
  const link = this.getAttribute("link");
  
  const image = this.getAttribute("image");
  
  const alt = this.getAttribute("alt") || "Game";
  
  const title = this.getAttribute("title") || "UnNamed";
  
  this.innerHTML = `
  <game-btn link="${link}" image="${image}" alt="${alt}" ></game-btn>
  <p class="game-title">${title}</p>
  `
  }
}

customElements.define("game-card", GameCard);