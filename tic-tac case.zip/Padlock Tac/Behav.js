/* Zona de variables */

const info_btn = document.querySelector("#howto");
const info = document.querySelector("#howto-play");
const turno = document.querySelector("#turno");
let tester = 1;

const dibujo = document.querySelector("#game-switch-draw");

const reservacion = document.querySelector("#game-switch-padlock");

let poner_o = true;
let dibujar = true;

const botones = document.querySelectorAll(".game-grid-btn");

let tablero = [
  0, 0, 0,
  0, 0, 0,
  0, 0, 0
]

const status = document.querySelector("#accion");

const SVG_candadoO = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="#7F8AFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <!-- Arco del candado semitransparente -->
  <path d="M7 10V7a5 5 0 0 1 10 0v3" stroke="#7F8AFF" />
  
  <!-- Cuerpo del candado con relleno semitransparente -->
  <rect x="3" y="10" width="18" height="12" rx="2" fill="#7F8AFF80" stroke="#7F8AFF" />
  
  <!-- Círculo (O) en el centro bien definido -->
  <circle cx="12" cy="16" r="2.5" stroke="#7F8AFF" stroke-width="2.2" />
</svg>
`;

const SVG_candadoX = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%" fill="none" stroke="#FF4B4B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <!-- Arco del candado -->
  <path d="M7 10V7a5 5 0 0 1 10 0v3" stroke="#FF4B4B" />
  
  <!-- Cuerpo del candado con relleno semitransparente -->
  <rect x="3" y="10" width="18" height="12" rx="2" fill="#FF4B4B80" stroke="#FF4B4B" />
  
  <!-- X en el centro -->
  <path d="M9.5 13.5l5 5" stroke="#FF4B4B" stroke-width="2.2" />
  <path d="M14.5 13.5l-5 5" stroke="#FF4B4B" stroke-width="2.2" />
</svg>
`;

const ganador = document.querySelector("#game-winner");

let contador = [0,0];

const restart = document.querySelector(".game-restart");

const ganadorTexto = document.querySelector("#game-winner-text");

const omitir = document.querySelector("#game-skip");

/* Fin de declaraciones */

/* Funciones */

function comprobar(arr) {
  if (
    (arr[0] === 1 && arr[3] === 1 && arr[6] === 1)
    ||
    (arr[0] === 1 && arr[4] === 1 && arr[8] === 1)
    ||
    (arr[0] === 1 && arr[1] === 1 && arr[2] === 1)
    ||
    (arr[3] === 1 && arr[4] === 1 && arr[5] === 1)
    ||
    (arr[6] === 1 && arr[7] === 1 && arr[8] === 1)
    ||
    (arr[2] === 1 && arr[5] === 1 && arr[8] === 1)
    ||
    (arr[1] === 1 && arr[4] === 1 && arr[7] === 1)
    ||
    (arr[2] === 1 && arr[4] === 1 && arr[6] === 1)
    ||
    (arr[3] === 1 && arr[4] === 1 && arr[5] === 1)
  )
  {
    console.log("gano la O");
    return 1;
  }
  else if (
    (arr[0] === -1 && arr[3] === -1 && arr[6] === -1)
    ||
    (arr[0] === -1 && arr[4] === -1 && arr[8] === -1)
    ||
    (arr[0] === -1 && arr[1] === -1 && arr[2] === -1)
    ||
    (arr[3] === -1 && arr[4] === -1 && arr[5] === -1)
    ||
    (arr[6] === -1 && arr[7] === -1 && arr[8] === -1)
    ||
    (arr[2] === -1 && arr[5] === -1 && arr[8] === -1)
    ||
    (arr[1] === -1 && arr[4] === -1 && arr[7] === -1)
    ||
    (arr[2] === -1 && arr[4] === -1 && arr[6] === -1)
    ||
    (arr[3] === -1 && arr[4] === -1 && arr[5] === -1)
  )
  {
    console.log("gano la X");
    return -1;
  }
  
  else if (
    (arr[0] != 0 && arr[0] != 2 && arr[0] != -2)
    &&
    (arr[1] != 0 && arr[1] != 2 && arr[1] != -2)
    &&
    (arr[2] != 0 && arr[2] != 2 && arr[2] != -2)
    &&
    (arr[3] != 0 && arr[3] != 2 && arr[3] != -2)
    &&
    (arr[4] != 0 && arr[4] != 2 && arr[4] != -2)
    &&
    (arr[5] != 0 && arr[5] != 2 && arr[5] != -2)
    &&
    (arr[6] != 0 && arr[6] != 2 && arr[6] != -2)
    &&
    (arr[7] != 0 && arr[7] != 2 && arr[7] != -2)
    &&
    (arr[8] != 0 && arr[8] != 2 && arr[8] != -2)
  )
  {
    console.log("Empate");
    return 777;
  }

}

/* Fin de funciones */

/* Eventos */

omitir.addEventListener("click", () => {
  
  let leer = tablero.some(casilla => casilla !== 0);
  
  if (!leer) {return;}
  
  poner_o = !poner_o;
  if (poner_o === false)
  {
    turno.innerHTML = '<span style="font-size: 2em;">x</span>';
    turno.style.color = "#FF4B4B";
  }
  else {
    turno.innerHTML = '<span style="font-size: 2em;">o</span>';
    turno.style.color = "#7F8AFF";
  }
});

restart.addEventListener("click", () => {
  tablero[0] = 0;
  tablero[1] = 0;
  tablero[2] = 0;
  tablero[3] = 0;
  tablero[4] = 0;
  tablero[5] = 0;
  tablero[6] = 0;
  tablero[7] = 0;
  tablero[8] = 0;
  botones.forEach((boton) => {
    boton.textContent = "";
  });
  ganador.style.visibility = "hidden";
  ganador.style.opacity = "0";
});

info_btn.addEventListener("click", () =>
{
  tester++;
  info.style.visibility = ((tester % 2) == 0)? "visible" : "hidden";
  info.style.opacity = ((tester % 2) == 0)? "1" : "0";
});

reservacion.addEventListener("click", () => {
  dibujar = false;
  status.textContent = "ST: Store";
});

dibujo.addEventListener("click", () => {
  dibujar = true;
  status.textContent = "ST: Drawing";
});

botones.forEach((boton) => {
  
  boton.addEventListener("click", (e) => {
    
    let index = parseInt(e.target.dataset.index);
    
    console.log(`tablero[${index}]`);
    
    if (poner_o === true && dibujar === true) {
      if (tablero[index] === 0 || tablero[index] === 2) {
        tablero[index] = 1;
        boton.textContent = "o";
        boton.style.color = "#7F8AFF";
        
        turno.innerHTML = '<span style="font-size: 2em;">x</span>';
        turno.style.color = "#FF4B4B";
        
        poner_o = false;
      }
    }
    
    else if (poner_o === false && dibujar === true) {
      if (tablero[index] === 0 || tablero[index] === -2)
      {
        tablero[index] = -1;
        boton.textContent = "x";
        boton.style.color = "#FF4B4B";
        
        turno.innerHTML = '<span style="font-size: 2em;">o</span>';
        turno.style.color = "#7F8AFF";
        
        poner_o = true;
      }
    }
    
    else if (poner_o === true && dibujar === false)
    {
      if (tablero[index] === 0)
      {
        tablero[index] = 2;
        boton.innerHTML = `${SVG_candadoO}`;
        
        turno.innerHTML = '<span style="font-size: 2em;">x</span>';
        turno.style.color = "#FF4B4B";
        
        poner_o = false;
      }
    }
    
    else if (poner_o === false && dibujar === false)
    {
      if (tablero[index] === 0)
      {
        tablero[index] = -2;
        boton.innerHTML = `${SVG_candadoX}`;
        
        turno.innerHTML = '<span style="font-size: 2em;">o</span>';
        turno.style.color = "#7F8AFF";
        
        poner_o = true;
      }
    }
    
    if (comprobar(tablero) === 1)
    {
      contador[0] += 1;
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #7F8AFF;
      font-size: 4em;
      ">
      O Wins</span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    else if (comprobar(tablero) === -1)
    {
      contador[1] += 1;
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #FF4B4B;
      font-size: 4em;
      ">
      X Wins</span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    
    else if (comprobar(tablero) === 777)
    {
      contador[0] += 1;
      contador[1] += 1;
      
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #FF4B4B;
      font-size: 4em;
      ">
      Dr<span style="
      color: #7F8AFF;
      ">aw</span></span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    
  });
  
});