# ¡ENGLISH!
# Only important things:

the <div> *howto-play* receives text from the variable *Name* in the file *behav.js*
# _DON'T WORRY_ about that <div>