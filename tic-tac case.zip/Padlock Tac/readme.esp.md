# ¡ESPAÑOL!
# Solo cosas importantes:

el <div> *howto-play* recibe texto desde la variable *Name* en el archivo *behav.js*
# _NO PREOCUPAR_ por ese <div>

Esta sección es solo para el minijuego Padlock Tac, dentro de el juego te muestra como se juego en el boton de informacion *i*