/* Zona de variables */

const info_btn = document.querySelector("#howto");
const info = document.querySelector("#howto-play");
const turno = document.querySelector("#turno");
let tester = 1;

const dibujo = document.querySelector("#game-switch-draw");

const reservacion = document.querySelector("#game-switch-padlock");

let poner_o = true;

const botones = document.querySelectorAll(".game-grid-btn");

let tablero = [
  0, 0, 0, 0,
  0, 0, 0, 0,
  0, 0, 0, 0,
  0, 0, 0, 0
]

const ganador = document.querySelector("#game-winner");

let contador = [0,0];

const restart = document.querySelectorAll(".game-restart");

const ganadorTexto = document.querySelector("#game-winner-text");

let ultimaJugada = null;
let ultimaEs_o = true;

/* Fin de declaraciones */

/* Funciones */

function comprobar(arr) {
  if (
    (arr[0] === 1 && arr[1] === 1 && arr[2] === 1 && arr[3] === 1)
    ||
    (arr[4] === 1 && arr[5] === 1 && arr[6] === 1 && arr[7] === 1)
    ||
    (arr[8] === 1 && arr[9] === 1 && arr[10] === 1 && arr[11] === 1)
    ||
    (arr[12] === 1 && arr[13] === 1 && arr[14] === 1 && arr[15] === 1)
    ||
    (arr[0] === 1 && arr[4] === 1 && arr[8] === 1 && arr[12] === 1)
    ||
    (arr[1] === 1 && arr[5] === 1 && arr[9] === 1 && arr[13] === 1)
    ||
    (arr[2] === 1 && arr[6] === 1 && arr[10] === 1 && arr[14] === 1)
    ||
    (arr[3] === 1 && arr[7] === 1 && arr[11] === 1 && arr[15] === 1)
    ||
    (arr[0] === 1 && arr[5] === 1 && arr[10] === 1 && arr[15] === 1)
    ||
    (arr[3] === 1 && arr[6] === 1 && arr[9] === 1 && arr[12] === 1)
  )
  {
    console.log("gano la O");
    return 1;
  }
  else if (
    (arr[0] === -1 && arr[1] === -1 && arr[2] === -1 && arr[3] === -1)
    ||
    (arr[4] === -1 && arr[5] === -1 && arr[6] === -1 && arr[7] === -1)
    ||
    (arr[8] === -1 && arr[9] === -1 && arr[10] === -1 && arr[11] === -1)
    ||
    (arr[12] === -1 && arr[13] === -1 && arr[14] === -1 && arr[15] === -1)
    ||
    (arr[0] === -1 && arr[4] === -1 && arr[8] === -1 && arr[12] === -1)
    ||
    (arr[1] === -1 && arr[5] === -1 && arr[9] === -1 && arr[13] === -1)
    ||
    (arr[2] === -1 && arr[6] === -1 && arr[10] === -1 && arr[14] === -1)
    ||
    (arr[3] === -1 && arr[7] === -1 && arr[11] === -1 && arr[15] === -1)
    ||
    (arr[0] === -1 && arr[5] === -1 && arr[10] === -1 && arr[15] === -1)
    ||
    (arr[3] === -1 && arr[6] === -1 && arr[9] === -1 && arr[12] === -1)
  )
  {
    console.log("gano la X");
    return -1;
  }
  
  else if (
    (arr[0] != 0)
    &&
    (arr[1] != 0)
    &&
    (arr[2] != 0)
    &&
    (arr[3] != 0)
    &&
    (arr[4] != 0)
    &&
    (arr[5] != 0)
    &&
    (arr[6] != 0)
    &&
    (arr[7] != 0)
    &&
    (arr[8] != 0)
    &&
    (arr[9] != 0)
    &&
    (arr[10] != 0)
    &&
    (arr[11] != 0)
    &&
    (arr[12] != 0)
    &&
    (arr[13] != 0)
    &&
    (arr[14] != 0)
    &&
    (arr[15] != 0)
  )
  {
    console.log("Empate");
    return 777;
  }

}

/* Fin de funciones */

/* Eventos */

restart.forEach((reinicio) => {
  reinicio.addEventListener("click", () => {
    tablero[0] = 0;
    tablero[1] = 0;
    tablero[2] = 0;
    tablero[3] = 0;
    tablero[4] = 0;
    tablero[5] = 0;
    tablero[6] = 0;
    tablero[7] = 0;
    tablero[8] = 0;
    tablero[9] = 0;
    tablero[10] = 0;
    tablero[11] = 0;
    tablero[12] = 0;
    tablero[13] = 0;
    tablero[14] = 0;
    tablero[15] = 0;
    botones.forEach((boton) => {
      boton.textContent = "";
    });
    ganador.style.visibility = "hidden";
    ganador.style.opacity = "0";
  });
});

info_btn.addEventListener("click", () =>
{
  tester++;
  info.style.visibility = ((tester % 2) == 0)? "visible" : "hidden";
  info.style.opacity = ((tester % 2) == 0)? "1" : "0";
});

botones.forEach((boton) => {
  
  boton.addEventListener("click", (e) => {
    
    let index = parseInt(e.target.dataset.index);
    
    console.log(`tablero[${index}]`);
    
    if (poner_o === true) {
      if (tablero[index] === 0)
      {
        tablero[index] = 1;
        boton.textContent = "o";
        boton.style.color = "#7F8AFF";
        
        turno.innerHTML = '<span style="font-size: 2em;">x</span>';
        turno.style.color = "#FF4B4B";
        
        poner_o = false;
      }
    }
    
    else if (poner_o === false) {
      if (tablero[index] === 0)
      {
        tablero[index] = -1;
        boton.textContent = "x";
        boton.style.color = "#FF4B4B";
        
        turno.innerHTML = '<span style="font-size: 2em;">o</span>';
        turno.style.color = "#7F8AFF";
        
        poner_o = true;
      }
    }
    
    if (comprobar(tablero) === 1)
    {
      contador[0] += 1;
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #7F8AFF;
      font-size: 4em;
      ">
      O Wins</span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    else if (comprobar(tablero) === -1)
    {
      contador[1] += 1;
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #FF4B4B;
      font-size: 4em;
      ">
      X Wins</span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    
    else if (comprobar(tablero) === 777)
    {
      contador[0] += 1;
      contador[1] += 1;
      
      ganador.style.visibility = "visible";
      ganador.style.opacity = "1";
      ganadorTexto.innerHTML = `
      <span style="
      color: #FF4B4B;
      font-size: 4em;
      ">
      Dr<span style="
      color: #7F8AFF;
      ">aw</span></span> <br><br><br><br>
      
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
      <span style="
      color: snow;
      font-size: 3.5em;
      ">
      <span style="color: #7F8AFF;">${contador[0]}</span>
      -
      <span style="color: #FF4B4B">
      ${contador[1]}
      </span>
      </span>
      
      <br><br>
      
      `;
    }
    
  });
  
});